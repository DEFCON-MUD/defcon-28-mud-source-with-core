# gurba-gen
Gurba mudlib code generator

# introduction
this was used in an attempt to port core to gurbalib as a present for dave shay
however gurba turned out to have some serious problems in a persistent world.
The mud was used for a CTF challenge at derbycon and is now complete.

# copyright
Copyright is hereby transferred From Dustin Heywood, aka EvilMog to Dave Shay for all the
core_ room and npc generation shellscript files.

core_npc.py makes gurba compat npc files
core_room.py generates gurba compat room files complete with exit code

# Dave
I originally built this so I could send you premade room files for inclusion to the
game once the timing issues were fixed. Sorry it went so completely far. I hereby transfer
you the code and volunteer to modify it to work for core.

I still owe you a whole bunch of areas to make up for breaking the game. I also still intend
to pay for hosting fees. Core made me the hacker I am today and I owe you everything for it.
